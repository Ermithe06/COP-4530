#include <iostream>
#include <utility>

//////////////////////////////////////
// Definition of TVector functions ///
//////////////////////////////////////

// Xian: SPARECAPACITY is the minimal size of the array, i.e., even an empty array will have this amount of elements. size determines the actual number of elements that are being tracked. 

// create empty vectcor
// Xian: empty vector means that the array is at the size of SPARECAPACITY without any values, size = 0. 
template <typename T> 
TVector<T>::TVector()
{
    capacity = SPARECAPACITY; 
    array = new T[capacity];
    // empty array, thus size = 0
    size = 0;
}

// create vector with num copies of val
template <typename T>
TVector<T>::TVector(T val, int num)
{
    // we have to set up capacity first because it determines the total size of array
    capacity = num + SPARECAPACITY;
    array = new T[capacity];
    size = num;
    for(int i = 0; i < num; i ++)
        array[i] = val;
}

// destructor
template <typename T>
TVector<T>::~TVector()
{
    delete [] array;
    array = nullptr;
}

// get the size
template<typename T>
int TVector<T>::GetSize() const
{
    return size;
}

// insert data d as last element
// uses reserve to increase capacity if the current capacity has been reached
template<typename T>
void TVector<T>::InsertBack(const T& d)
{
   if (size == capacity)
        SetCapacity(2 * capacity + 1);

    array[size ++] = d;
}

// next item available
// return iterator to first item
template<typename T>
TVectorIterator<T> TVector<T>::GetIterator() const
{
    TVectorIterator<T> it;
    if(size > 0)
    {
        it.ptr = array;
        it.index = 0;
        it.vsize = size;
    }
    return it;
}

// remove data item at position pos. Return iterator to the item 
// that comes after the one being deleted
template<typename T>
TVectorIterator<T> TVector<T>::Remove(TVectorIterator<T> pos)
{
    if(size == 0 || pos.index >= size || pos.index < 0)
    {
        TVectorIterator<T> ret_pos;
        return ret_pos;
    }
    
    TVectorIterator<T> ret_pos = pos;
    // move the items after the pos.index one position ahead
    for(int i = pos.index; i < size - 1; i ++)
        array[i] = array[i + 1];
    size --;
    ret_pos.vsize = size;
    
    return ret_pos;
}

// print vector contents in order, separated by given delimiter
template<typename T>
void TVector<T>::Print(std::ostream& os, char delim) const
{
    if(size == 0)
    	os << "Nothing to print. size is 0." << std::endl;

    os << array[0];
    for(int i = 1; i < size; i ++)
        os << delim << array[i];
}
 
//clear: reset vector to empty
template <typename T>
void TVector<T>::Clear()
{
    size = 0;
}

//copy constructor
template <typename T>
TVector<T>::TVector(const TVector<T>& v)
{
    capacity = v.capacity; //set capacity to the one in v 
    size = v.size; //set size to the one in v 
    array = new T[capacity]; 
	
	//copy the elements from the array in v to the new array
    for(int i = 0; i < size; i++)
        array[i] = v.array[i];
}

//copy assignment operator
template <typename T>
TVector<T>& TVector<T>::operator=(const TVector<T>& v)
{
    if(this != &v)
    {
        TVector<T> temp(v);
		
		//swap everything in the temp object to the current this object
        std::swap(array, temp.array);
        std::swap(size, temp.size);
        std::swap(capacity, temp.capacity);
    }
    return *this;
}

//move constructor
template <typename T>
TVector<T>::TVector(TVector<T>&& v)
{
	//set array, size, capacity to the ones in v
    array = v.array;
    size = v.size;
    capacity = v.capacity;
	
	//set array, size, capacity of v to default
    v.array = nullptr;
    v.size = 0;
    v.capacity = 0;
}

//move assignment
template <typename T>
TVector<T>& TVector<T>::operator=(TVector<T>&& v)
{
    if(this != &v)
    {
		//swap the data in v to the current object
        std::swap(array, v.array);
        std::swap(size, v.size);
        std::swap(capacity, v.capacity);
    }
    return *this;
}

//IsEmpty
template <typename T>
bool TVector<T>::IsEmpty() const
{
    return size == 0;
}

//RemoveBack
//if the array is not empty, decrease the array size by 1 to "remove" the last element
template <typename T>
void TVector<T>::RemoveBack()
{
    if(size > 0)
        size--;
}

//GetFirst
//return the dummy if array is empty else return the first element in the array
template <typename T>
T& TVector<T>::GetFirst() const
{
    if(size == 0)
	{
        return dummy;
	}
    return array[0];
}

//GetLast
//return the dummy if array is empty else return the last element in the array
template <typename T>
T& TVector<T>::GetLast() const
{
    if(size == 0)
        return dummy;
    return array[size - 1];
}

//SetCapacity
//resizes the vector's capacity to c
template <typename T>
void TVector<T>::SetCapacity(unsigned int c)
{
    T* newArray = new T[c];
    unsigned int newSize;
	if (size > c)
	{
    newSize = c;
	}else{
    newSize = size;
	}

    for(int i = 0; i < newSize; i++)
	{
        newArray[i] = array[i];
	}
    delete [] array;
    array = newArray;
    capacity = c;
    size = newSize;
}

//GetIteratorEnd
template <typename T>
TVectorIterator<T> TVector<T>::GetIteratorEnd() const
{
    TVectorIterator<T> itr;
	
	//if array is not empty, vsize stay the same as size
	//change index to last the index and ptr to the last element 
    if(size > 0)
    {
        itr.index = size - 1;
        itr.vsize = size;
		itr.ptr = array + (size - 1);
    }
    return itr;
}

//Insert
template <typename T>
TVectorIterator<T> TVector<T>::Insert(TVectorIterator<T> pos, const T& d)
{
	//if array is at capacity, double the array capacity
    if(size == capacity)
        SetCapacity(2 * capacity + 1);

    TVectorIterator<T> itr = pos;

	//if array is empty, insert at position 0 
	//and update itr's variables
    if(size == 0)
    {
        array[0] = d;
        size = 1;
        itr.ptr = array;
        itr.index = 0;
        itr.vsize = size;
        return itr;
    }

	//move elements to the right
    if(pos.index >= 0 && pos.index < size)
    {
        for(int i = size; i > pos.index; i--)
            array[i] = array[i-1];
        array[pos.index] = d;
        size++;
        itr.ptr = array + pos.index;
        itr.vsize = size;
        return itr;
    }

    array[size] = d;
    itr.ptr = array + size;
    itr.index = size;
    size++;
    itr.vsize = size;
    return itr;
}

//Remove (two parameters)
template <typename T>
TVectorIterator<T> TVector<T>::Remove(TVectorIterator<T> pos1, 
TVectorIterator<T> pos2)
{
	//check if valid
    if(size == 0 || pos1.index < 0 || pos2.index > size || pos1.index >= pos2.index)
	{  
		return pos1;
	}

	//shift the elements left, shrink size, and return an iterator to the new position
    int shiftCount = pos2.index - pos1.index;
    for(int i = pos1.index; i + shiftCount < size; i++)
        array[i] = array[i + shiftCount];
    size -= shiftCount;

    TVectorIterator<T> itr = pos1;
    itr.ptr = array + pos1.index;
    itr.vsize = size;
    return itr;
}

//standalone operator+
//creates a new vector by concatenating the elements of t1 followed by t2.  
template <typename T>
TVector<T> operator+(const TVector<T>& t1, const TVector<T>& t2)
{
    TVector<T> v(t1);
    TVectorIterator<T> itr = t2.GetIterator();
    for(int i = 0; i < t2.GetSize(); i++)
    {
        v.InsertBack(itr.GetData());
        if(itr.HasNext())
            itr = itr.Next();
    }
    return v;
}
 
/////////////////////////////////////////////
// Definition of TVectorIterator functions //
/////////////////////////////////////////////

//default constructor
template <typename T>
TVectorIterator<T>::TVectorIterator()
{
    ptr = nullptr;
    vsize = 0;
}

//HasNext
template <typename T>
bool TVectorIterator<T>::HasNext() const
{
    return (ptr != nullptr && index + 1 < vsize);
}

//HasPrevious
template <typename T>
bool TVectorIterator<T>::HasPrevious() const
{
    return (ptr != nullptr && index > 0);
}

//Next
template <typename T>
TVectorIterator<T> TVectorIterator<T>::Next()
{
    if(ptr != nullptr && HasNext())
    {
        ++index;
        ++ptr;
    }
    return *this;
}

//Previous
template <typename T>
TVectorIterator<T> TVectorIterator<T>::Previous()
{
    if(ptr != nullptr && HasPrevious())
    {
        --index;
        --ptr;
    }
    return *this;
}

//GetData
template <typename T>
T& TVectorIterator<T>::GetData() const
{
    if(ptr == nullptr)
        return TVector<T>::dummy;
    return *ptr;
}

