#ifndef BET_H
#define BET_H

#include <string>
#include <cstddef>

using namespace std;

class BET {
public:
	//A nested structure to contain the node-related information
    struct BinaryNode {
        string element;
        BinaryNode *left;
        BinaryNode *right;
		
		//Children nodes
        BinaryNode(const string & theElement,
                   BinaryNode *lt,
                   BinaryNode *rt)
            : element(theElement), left(lt), right(rt) {}

        BinaryNode(string && theElement,
                   BinaryNode *lt,
                   BinaryNode *rt)
            : element(move(theElement)), left(lt), right(rt) {}
    };

private:
    BinaryNode *root;

public:
    BET(); //default constructor
    BET(const string & postfix); //one parameter constructor
    BET(const BET & rhs); //copy constructor
    ~BET(); //destructor

	//parameter "postfix"
    bool buildFromPostfix(const string & postfix);
	
	//assignment operator
    const BET & operator= (const BET & rhs); 

	//print out the inflix and postfix expressions
    void printInfixExpression() const;
    void printPostfixExpression() const;

	//The number of nodes and leaf nodes in the tree
    size_t size() const;
    size_t leaf_nodes() const;
    bool empty() const;

private:
	//print the inflix and postfix of the subtree
    void printInfixExpression(BinaryNode *n) const;
    void printPostfixExpression(BinaryNode *n) const;

	//clone or delete all nodes in the subtree
    BinaryNode * clone(BinaryNode *t) const;
    void makeEmpty(BinaryNode * & t);

	//The number of nodes and leaf nodes in the subtree
    size_t size(BinaryNode *t) const;
    size_t leaf_nodes(BinaryNode *t) const;
};

#endif
