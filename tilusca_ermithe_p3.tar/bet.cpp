#include "bet.h"

#include <iostream>
#include <sstream>
#include <stack>

using namespace std;

//the four types of operators
static bool isOperator(const string &op) {
    return op == "*" || op == "/" || op == "+" || op == "-";
}

//Precedence of the operators, left to right. 
//multiplication and division have higher precedence than plus and minus
static int precedence(const string &op) {
    if (op == "*" || op == "/") return 2;
    if (op == "+" || op == "-") return 1;
    return 0; 
}

//Set up the root of the tree
BET::BET() : root(nullptr) {}

//This function called buildFromPostfix function
BET::BET(const string & postfix) : root(nullptr) {
    buildFromPostfix(postfix);
}

//This function calls clone function
BET::BET(const BET & rhs) : root(nullptr) {
    root = clone(rhs.root);
}

//This function calls makeEmpty function
BET::~BET() {
    makeEmpty(root);
}

//This function calls makeEmpty if the tree is not empty. then it calls clone
const BET & BET::operator=(const BET & rhs) {
    if (this != &rhs) {
        makeEmpty(root);
        root = clone(rhs.root);
    }
    return *this;
}

//The tree is built based on the postfix expression. Tokens in the postfix expression are separated by spaces. 
//If the tree contains nodes before the function is called, the existing nodes are deleted
bool BET::buildFromPostfix(const string & postfix) {
    makeEmpty(root);

    istringstream iss(postfix);
    string token;
    stack<BinaryNode*> st;
    bool seenToken = false;

    while (iss >> token) {
        seenToken = true;

        if (!isOperator(token)) {
            st.push(new BinaryNode(token, nullptr, nullptr));
        } else {
            if (st.size() < 2) {
                cout << "Cannot build the tree based on " << postfix << "\n";
                while (!st.empty()) { makeEmpty(st.top()); st.pop(); }
                return false;
            }
            BinaryNode *right = st.top(); st.pop();
            BinaryNode *left = st.top(); st.pop();

            st.push(new BinaryNode(token, left, right));
        }
    }

	//If an error is encountered, output the error message 
    if (!seenToken || st.size() != 1) {
        cout << "Cannot build the tree based on " << postfix << "\n";
        while (!st.empty()) { makeEmpty(st.top()); st.pop(); }
        return false;
    }

    root = st.top();
    return true;
}

//Print out the infix expression. This function simply calls its private (recursive) version
void BET::printInfixExpression() const {
    if (root)
        printInfixExpression(root);
    cout << "\n";
}

//Print out the postfix expression. This function simply calls its private (recursive) version
void BET::printPostfixExpression() const {
    if (root)
        printPostfixExpression(root);
    cout << "\n";
}

//rint to the standard output the corresponding infix expression of the subtree pointed to by n
void BET::printInfixExpression(BinaryNode *n) const {
    if (!n) return;

    if (!isOperator(n->element)) {
        cout << n->element;
        return;
    }

    bool parenLeft  = false;
    bool parenRight = false;

    if (n->left && isOperator(n->left->element)) {
        if (precedence(n->left->element) < precedence(n->element))
            parenLeft = true;
    }

    if (n->right && isOperator(n->right->element)) {
        int cp = precedence(n->right->element);
        int pp = precedence(n->element);

        if (cp < pp) parenRight = true;
        if (cp == pp) parenRight = true;   
    }

    if (parenLeft)  cout << "( ";
    printInfixExpression(n->left);
    if (parenLeft)  cout << " )";

    cout << " " << n->element << " ";

    if (parenRight) cout << "( ";
    printInfixExpression(n->right);
    if (parenRight) cout << " )";
}

//rint to the standard output the corresponding postfix expression of the subtree pointed to by n
void BET::printPostfixExpression(BinaryNode *n) const {
    if (!n) return;
    printPostfixExpression(n->left);
    printPostfixExpression(n->right);
    cout << n->element << " ";
}

//clone all nodes in the subtree pointed to by t
BET::BinaryNode * BET::clone(BinaryNode *t) const {
    if (!t) return nullptr;
    return new BinaryNode(
            t->element,
            clone(t->left),
            clone(t->right)
    );
}

//delete all nodes in the subtree pointed to by t
void BET::makeEmpty(BinaryNode * & t) {
    if (!t) return;
    makeEmpty(t->left);
    makeEmpty(t->right);
    delete t;
    t = nullptr;
}

//Return the number nodes in the tree. This function calls its private (recursive) version.
size_t BET::size() const {
    return size(root);
}

//Return the number of leaf nodes in the tree. This function calls its private (recursive) version.
size_t BET::leaf_nodes() const {
    return leaf_nodes(root);
}

//return the number of nodes in the subtree pointed to by t
size_t BET::size(BinaryNode *t) const {
    if (!t) return 0;
    return 1 + size(t->left) + size(t->right);
}

//return the number of leaf nodes in the subtree pointed to by t
size_t BET::leaf_nodes(BinaryNode *t) const {
    if (!t) return 0;
    if (!t->left && !t->right) return 1;
    return leaf_nodes(t->left) + leaf_nodes(t->right);
}

bool BET::empty() const {
    return root == nullptr;
}
