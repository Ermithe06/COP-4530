#ifndef HASHTABLE_HPP
#define HASHTABLE_HPP

#include "hashtable.h"

template <typename K, typename V>
unsigned long HashTable<K, V>::prime_below(unsigned long n)
{
  if (n > max_prime)
    {
      std::cerr << "** input too large for prime_below()\n";
      return 0;
    }
  if (n == max_prime)
    {
      return max_prime;
    }
  if (n <= 1)
    {
		std::cerr << "** input too small \n";
      return 0;
    }


  // now: 2 <= n < max_prime
  std::vector <unsigned long> v (n+1);
  setPrimes(v);
  while (n > 2)
    {
      if (v[n] == 1)
	return n;
      --n;
    }

  return 2;
}

template <typename K, typename V>
void HashTable<K, V>::setPrimes(vector<unsigned long> & vprimes)
{
  int i = 0;
  int j = 0;

  vprimes[0] = 0;
  vprimes[1] = 0;
  int n = vprimes.capacity();

  for (i = 2; i < n; ++i)
    vprimes[i] = 1;

  for( i = 2; i*i < n; ++i)
    {
      if (vprimes[i] == 1)
        for(j = i + i ; j < n; j += i)
          vprimes[j] = 0;
    }
}

//return the size of the hash table
template <typename K, typename V>
HashTable<K,V>::HashTable(size_t size)
{
    if (size <= 0)
        size = default_capacity;

    size = prime_below(size);
    if (size <= 0)
        size = default_capacity;

    theLists.resize(size);
    currentSize = 0;
}

//destructor, delete all elements in hash table
template <typename K, typename V>
HashTable<K,V>::~HashTable()
{
    clear();
}

//check if key k is in the hash table
template <typename K, typename V>
bool HashTable<K,V>::contains(const K & k) const
{
    auto & whichList = theLists[ myhash(k) ];
    for (const auto & p : whichList)
        if (p.first == k)
            return true;
    return false;
}

//check if key-value pair is in the hash table
template <typename K, typename V>
bool HashTable<K,V>::match(const std::pair<K,V> & kv) const
{
    auto & whichList = theLists[ myhash(kv.first) ];
    for (const auto & p : whichList)
        if (p == kv)
            return true;
    return false;
}

//add  the key-value pair kv into the hash table
template <typename K, typename V>
bool HashTable<K,V>::insert(const std::pair<K,V> & kv)
{
    auto & whichList = theLists[ myhash(kv.first) ];

    for (const auto & p : whichList)
        if (p.first == kv.first)//If the kv is in the hashtable, don't add
            return false; 

    whichList.push_back(kv); //if the key is already in the hash table, update v

    if (++currentSize > theLists.size())
        rehash();

    return true; //Return true if kv is inserted or the v is updated
}

//move version of insert
template <typename K, typename V>
bool HashTable<K,V>::insert(std::pair<K,V> && kv)
{
    auto & whichList = theLists[ myhash(kv.first) ];

    for (const auto & p : whichList)
        if (p.first == kv.first)
            return false;

    whichList.push_back(std::move(kv));

    if (++currentSize > theLists.size())
        rehash();

    return true;
}

//delete the key k and the corresponding value if it is in the hash table
template <typename K, typename V>
bool HashTable<K,V>::remove(const K & k)
{
    auto & whichList = theLists[ myhash(k) ];

    for (auto it = whichList.begin(); it != whichList.end(); ++it)
    {
        if (it->first == k) //Return true if k is deleted
        {
            whichList.erase(it);
            --currentSize;
            return true;
        }
    }
    return false; //return false otherwise (i.e., if key k is not in the hash table)
}

//delete all elements in the hash table
template <typename K, typename V>
void HashTable<K,V>::clear()
{
    makeEmpty();
}

//Private helper function
template <typename K, typename V>
void HashTable<K,V>::makeEmpty()
{
    for (auto & lst : theLists)
        lst.clear();

    currentSize = 0; //delete all elements in the hash table
}

//load the content of the file with name filename into the hash table
template <typename K, typename V>
bool HashTable<K,V>::load(const char * filename)
{
    std::ifstream file(filename);
    if (!file)//Return false if the file does not exist
        return false;

	//each line contains a single pair of key and value
    K key;
    V val;

    while (file >> key >> val)
    {
		//If the key already exists, output error message and do not insert
        if (contains(key)) {
            std::cerr << "Error: duplicate key \"" << key << "\".\n";
            continue;
        }
        insert(std::make_pair(key, val)); //Otherwise, insert the key and value pair
    }
    return true;
}

// write_to_file
template <typename K, typename V>
bool HashTable<K,V>::write_to_file(const char * filename) const
{
    std::ofstream file(filename);//write all entries in the hash table into a file with name filename
    if (!file)
        return false;

    for (const auto & lst : theLists)
        for (const auto & p : lst)
            file << p.first << " " << p.second << "\n";

    return true;
}

//display all entries in the hash table. Each row represents an item in the vector
template <typename K, typename V>
void HashTable<K,V>::dump() const
{
    for (size_t i = 0; i < theLists.size(); ++i)
    {
        std::cout << "v[" << i << "]:";
        bool first = true;

        for (const auto & p : theLists[i])
        {
            if (!first) std::cout << " :";
            std::cout << p.first << ", " << p.second;
            first = false;
        }
        std::cout << "\n";
    }
}

//size
template <typename K, typename V>
size_t HashTable<K,V>::size() const
{
    return currentSize;
}

//return the index of the vector entry where k should be stored
template <typename K, typename V>
size_t HashTable<K,V>::myhash(const K & k) const
{
    static std::hash<K> hf;
    size_t hashedValue = hf(k);

    // Debug print EXACTLY like the professor’s version
    std::cout << "hashed position of " << k << " is " << hashedValue << std::endl;

    return hashedValue % theLists.size();
}

//Called when the number of elements in the hash table is greater than the size of the vector
template <typename K, typename V>
void HashTable<K,V>::rehash()
{
	std::cout << "rehash is called here. " << std::endl;
    std::vector<std::list<std::pair<K,V>>> oldLists = theLists;

    theLists.resize(prime_below(2 * theLists.size()));
    makeEmpty();

    for (auto & lst : oldLists)
        for (auto & p : lst)
            insert(std::move(p));
}

#endif