#include "passserver.h"
#include <unistd.h>    // crypt()
#include <string>

using std::string;
using std::pair;

// Xian: in a shell, type "man crypt", and the MD5 can be found (which uses 22 characters of the password), and the usage will be shown as well.
// Note that it takes c_str, char [], not string directly as the input arguments. 
string PassServer::encrypt(const string & str) {
        char salt[] = "$1$########";
        char * password = new char [35];
        strcpy(password, crypt(str.c_str(), salt));


        string pword(password);
        string delim = "$";
        int pos = pword.find(delim, 0);
        pos = pword.find(delim, pos+1);
        pos = pword.find(delim, pos+1);
        pword.erase(0, pos+1);
        return pword;
	/*char salt[] = "$1$########";
	string ret = crypt(str.c_str(), salt);
	return ret.substr(1, 22);*/
}

//constructor, create a hash table of the specified size
PassServer::PassServer(size_t size)
    : h(size)//this size parameter to the constructor of the HashTable
{
}

//destructor, calls the clear() function in HashTable
PassServer::~PassServer()
{
   h.clear();
}

//load a password file into the HashTable object
bool PassServer::load(const char * filename)
{
    return h.load(filename);
}

//add a new username and password
bool PassServer::addUser(pair<string,string> & kv)
{
    kv.second = encrypt(kv.second);
    return h.insert(kv);
}

//move version of addUser
bool PassServer::addUser(pair<string,string> && kv)
{
    kv.second = encrypt(kv.second); //encrypted before insertion
    return h.insert(std::move(kv));
}

//delete an existing user with username k
bool PassServer::removeUser(const string & k)
{
    return h.remove(k);
}

//change an existing user's password
bool PassServer::changePassword(const pair<string,string> & p,
                                const string & newpassword)
{
    // If the user is not in the hash table, return false
    if (!h.contains(p.first))
        return false;

	//encrypted before interacted with the hash table
    string old_enc = encrypt(p.second);
    string new_enc = encrypt(newpassword);

	//return false if the new password and the old password are the same
    if (old_enc == new_enc)
        return false;

    pair<string,string> oldpair(p.first, old_enc);

	//If p.second does not match the current password, return false
    if (!h.match(oldpair))
        return false;

    h.remove(p.first);

    pair<string,string> newpair(p.first, new_enc);
    h.insert(newpair);

    return true;
}

//check if a user exists (if user is in the hash table)
bool PassServer::find(const string & user) const
{
    return h.contains(user);
}

//show the structure and contents of the HashTable object to the screen
void PassServer::dump() const
{
    h.dump();
}

//return the size of the HashTable
size_t PassServer::size() const
{
    return h.size(); //(the number of username/password pairs in the table)
}

//save the username and password combination into a file
bool PassServer::write_to_file(const char * filename) const
{
    return h.write_to_file(filename); //Same format as the write_to_file() function in the HashTable class template
}

